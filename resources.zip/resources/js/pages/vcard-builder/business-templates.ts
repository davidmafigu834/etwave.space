export {
  BUSINESS_TYPE_ALIASES,
  getBusinessTemplate,
  businessTemplates,
  getDefaultSections,
  resolveBusinessType,
  businessTypeOptions
} from './business-templates/index';
