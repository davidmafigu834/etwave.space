module.exports = {
	extends: ['plugin:@woocommerce/eslint-plugin/recommended'],
	rules: {
		'react/react-in-jsx-scope': 'off',
	},
};
