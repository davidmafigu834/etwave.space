# Paynow Payment Gateway 

A payment gateway for Paynow. A Paynow merchant account, merchant key and merchant ID are required for this gateway to function.

## Important Note

An SSL certificate is recommended for additional safety and security for your customers.

Please update your permalink settings by navigating to "Settings" and then "Permalinks" to select a anything other than the default option for your website's URL structure

Install like any other Wordpress plugin, then Paynow appears as a payment option on WooCommerce.

## Release Notes
We have added support for express checkout with mobile wallets(Ecocash, One Money and Innbucks)

.
