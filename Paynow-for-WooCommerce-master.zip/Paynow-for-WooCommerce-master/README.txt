=== Paynow Zimbabwe Payment Gateway ===
Contributors: webdevprojects
Tags: Paynow, Woocommerce
Requires at least: 4.7
Tested up to: 6.8
Stable tag: 1.3.5
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Paynow Payment  Gateway for Zimbabwean Payment System. Receive payments from various Zimbabwean Mobile Wallets, Visa/Mastercard.

